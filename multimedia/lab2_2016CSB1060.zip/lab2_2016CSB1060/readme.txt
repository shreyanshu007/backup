Music file if not present in the folder due to exceeding upload size limit on moodle.
So to run the code you need to provide one music fil -> music \.wav


TO run
	$python lab3.py